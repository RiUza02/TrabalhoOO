package IA;

import model.Campo;
//yuri Alexsander Sudre Almeida Souza   202065512b
//Rafaela da Silva Cunha    202065509b
//Victor Aluisio dos Santos Oliveira    202065091ab

public abstract class Bot {

    public abstract void atirar();

    public abstract void imprime();

    public abstract boolean achouTudo();

    public abstract Campo getCampo();

    public abstract int getX();

    public abstract int getY();

}
