package BatalhaNaval;
//yuri Alexsander Sudre Almeida Souza   202065512b
//Rafaela da Silva Cunha    202065509b
//Victor Aluisio dos Santos Oliveira    202065091ab

public class Trabalho {

    public static void main(String[] args) {
        Tela tela = new Tela();
        tela.TelaMenu();
    }
}
